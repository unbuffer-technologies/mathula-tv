from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from mathula_tv.azure_tts import AzureTTSResult
from mathula_tv.cli import parser
from mathula_tv.direct_azure_dub import (
    DirectAzureDubRenderer,
    DirectDubArtifacts,
    DirectDubOptions,
    SpeechBlock,
    SEMANTIC_FIT_SCHEMA_VERSION,
    TimingOverflowError,
    TIMING_MODE_SEMANTIC_FIT,
    _DirectDubProgress,
    _selected_azure_measurement_ms,
    create_direct_azure_backend,
)
from mathula_tv.errors import ClaudeRateLimit
from mathula_tv.tts_ssml import BreakPart


class _MeasuredBackend:
    sample_rate = 16_000
    ssml_bounds = SimpleNamespace(
        rate_min_percent=-50,
        rate_max_percent=50,
        total_pause_max_ms=10_000,
    )

    def __init__(self, durations: dict[str, int]) -> None:
        self.durations = durations
        self.rates: list[int] = []

    def synthesize(self, request, output_path: Path, *, force: bool):
        self.rates.append(request.rate_percent)
        duration_ms = self.durations[request.text] + sum(
            part.duration_ms
            for part in request.parts
            if isinstance(part, BreakPart)
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(f"wav:{request.text}".encode())
        digest = hashlib.sha256(output_path.read_bytes()).hexdigest()
        return AzureTTSResult(
            backend="test",
            turn_id=request.turn_id,
            speaker_id=request.speaker_id,
            voice=request.voice or "voice",
            language=request.language,
            input_text_hash=digest,
            ssml_hash=digest,
            output_path=str(output_path),
            sample_rate=self.sample_rate,
            channels=1,
            sample_width=2,
            duration_ms=duration_ms,
            preferred_duration_ms=request.preferred_duration_ms,
            maximum_duration_ms=request.maximum_duration_ms,
            rate_percent=request.rate_percent,
            attempt=1,
            sha256=digest,
            warnings=(),
            request_hash=digest,
            ssml_path=str(output_path.with_suffix(".ssml")),
            manifest_path=str(output_path.with_suffix(".json")),
            ssml_summary="test",
            idempotent_reuse=False,
        )


class _PauseOvershootBackend(_MeasuredBackend):
    def __init__(self, durations: dict[str, int], *, pause_overhead_ms: int) -> None:
        super().__init__(durations)
        self.pause_overhead_ms = pause_overhead_ms

    def synthesize(self, request, output_path: Path, *, force: bool):
        result = super().synthesize(request, output_path, force=force)
        if any(isinstance(part, BreakPart) for part in request.parts):
            return AzureTTSResult(
                **{
                    **result.__dict__,
                    "duration_ms": result.duration_ms + self.pause_overhead_ms,
                }
            )
        return result


class _SemanticProvider:
    def __init__(self) -> None:
        self.fit_calls = 0
        self.review_calls = 0

    def fit_turn_semantically(self, payload):
        self.fit_calls += 1
        unit_id = payload["unit_id"]
        return SimpleNamespace(
            data={
                "schema_version": "claude-turn-repair-v1",
                "unit": {
                    "unit_id": unit_id,
                    "faithful_translation": "Ukuhumusha okugunyaziwe",
                    "spoken_text": "Umusho olingana kahle",
                    "tts_text": "Umusho olingana kahle",
                    "language_features": [],
                    "human_review_flags": [],
                    "numbers_preserved": True,
                    "dates_preserved": True,
                    "negation_preserved": True,
                    "omitted_or_compressed_detail": [],
                },
            }
        )

    def review_semantic_fit(self, payload):
        self.review_calls += 1
        return SimpleNamespace(
            data={
                "schema_version": "claude-semantic-fit-review-v1",
                "accepted": True,
                "required_fact_ids_preserved": [
                    item["fact_id"] for item in payload["required_facts"]
                ],
                "protected_entities_preserved": payload["protected_entities"],
                "attribution_preserved": True,
                "uncertainty_preserved": True,
                "negation_preserved": True,
                "no_new_facts": True,
                "natural_spoken_target_language": True,
                "semantic_fidelity_score": 99,
                "naturalness_score": 95,
                "reason_codes": [],
            }
        )


class _SemanticBatchProvider:
    def __init__(
        self,
        candidates: dict[str, str],
        *,
        review_rate_limits: int = 0,
        retry_after_seconds: float = 0.25,
    ) -> None:
        self.candidates = candidates
        self.fit_batch_calls = 0
        self.review_batch_calls = 0
        self.review_rate_limits = review_rate_limits
        self.retry_after_seconds = retry_after_seconds
        self.sleep_calls: list[float] = []
        self.sleep = self.sleep_calls.append

    def fit_turns_semantically(self, payload):
        self.fit_batch_calls += 1
        repairs = []
        for request in payload["repairs"]:
            unit_id = request["unit_id"]
            spoken = self.candidates[unit_id]
            repairs.append(
                {
                    "unit_id": unit_id,
                    "candidate": {
                        "schema_version": "claude-turn-repair-v1",
                        "unit": {
                            "unit_id": unit_id,
                            "faithful_translation": request["current_translation"][
                                "faithful_translation"
                            ],
                            "spoken_text": spoken,
                            "tts_text": spoken,
                            "language_features": [],
                            "human_review_flags": [],
                            "numbers_preserved": True,
                            "dates_preserved": True,
                            "negation_preserved": True,
                            "omitted_or_compressed_detail": [],
                        },
                    },
                }
            )
        return SimpleNamespace(
            data={
                "schema_version": "claude-semantic-fit-batch-v1",
                "repairs": repairs,
            }
        )

    def review_semantic_fits(self, payload):
        self.review_batch_calls += 1
        if self.review_batch_calls <= self.review_rate_limits:
            raise ClaudeRateLimit(
                "test rate limit",
                details={
                    "status_code": 429,
                    "retry_after_seconds": self.retry_after_seconds,
                },
            )
        reviews = []
        for request in payload["reviews"]:
            reviews.append(
                {
                    "unit_id": request["unit_id"],
                    "review": {
                        "schema_version": "claude-semantic-fit-review-v1",
                        "accepted": True,
                        "required_fact_ids_preserved": [
                            item["fact_id"]
                            for item in request["required_facts"]
                        ],
                        "protected_entities_preserved": request[
                            "protected_entities"
                        ],
                        "attribution_preserved": True,
                        "uncertainty_preserved": True,
                        "negation_preserved": True,
                        "no_new_facts": True,
                        "natural_spoken_target_language": True,
                        "semantic_fidelity_score": 99,
                        "naturalness_score": 95,
                        "reason_codes": [],
                    },
                }
            )
        return SimpleNamespace(
            data={
                "schema_version": "claude-semantic-fit-review-batch-v1",
                "reviews": reviews,
            }
        )

def _block() -> SpeechBlock:
    return SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=2000,
        segment_ids=("unit_0001",),
        source_text="The source sentence",
        translated_text="Ukuhumusha okugunyaziwe",
        tts_text="Ukuhumusha okugunyaziwe",
        required_facts=("The source sentence remains true",),
    )


def test_semantic_fit_cli_is_opt_in() -> None:
    balanced = parser().parse_args(["dub-azure", "job-1"])
    semantic = parser().parse_args(
        [
            "dub-azure",
            "job-1",
            "--timing-mode",
            "semantic-fit",
            "--semantic-fit-max-attempts",
            "9",
        ]
    )

    assert balanced.timing_mode == "balanced"
    assert semantic.timing_mode == "semantic-fit"
    assert semantic.semantic_fit_max_attempts == 9


def test_semantic_fit_options_reject_invalid_limits() -> None:
    backend = _MeasuredBackend({})
    with pytest.raises(ValueError, match="attempts"):
        DirectDubOptions(
            timing_mode=TIMING_MODE_SEMANTIC_FIT,
            semantic_fit_max_attempts=0,
        ).validate(backend)


def test_semantic_fit_payload_forbids_rate_and_stretch_repairs() -> None:
    payload = DirectAzureDubRenderer._semantic_fit_payload(
        _block(),
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=-3,
        pitch_percent=0,
        volume_percent=0,
        attempt_number=2,
        target_minimum_ms=1650,
        target_preferred_ms=1900,
        target_maximum_ms=2000,
        duration_evidence=[{"measured_duration_ms": 2200}],
        rejected_spoken_texts=["Ukuhumusha okugunyaziwe"],
        current_spoken_text="Ukuhumusha okugunyaziwe",
    )

    assert payload["synthesis_profile"]["rate_percent"] == -3
    assert payload["synthesis_profile"]["tempo_locked"] is True
    assert payload["constraints"]["per_block_rate_change_allowed"] is False
    assert payload["constraints"]["post_synthesis_time_stretch_allowed"] is False
    assert payload["target_duration_band_ms"] == {
        "minimum": 1650,
        "preferred": 1900,
        "maximum": 2000,
    }


def test_semantic_fit_measures_one_candidate_at_locked_rate_and_reviews_it(
    tmp_path: Path,
) -> None:
    backend = _MeasuredBackend(
        {
            "Ukuhumusha okugunyaziwe": 1400,
            "Umusho olingana kahle": 1800,
        }
    )
    provider = _SemanticProvider()
    settings = SimpleNamespace(work_dir=tmp_path)
    renderer = DirectAzureDubRenderer(
        settings,
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    artifacts = DirectDubArtifacts(tmp_path / "jobs" / "job-1")

    selected_block, fitted, attempts = renderer._synthesize_semantic_fit(
        _block(),
        artifacts,
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=-3,
        pitch_percent=0,
        volume_percent=0,
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
        block_number=1,
        block_total=1,
    )

    assert selected_block.translated_text == "Umusho olingana kahle"
    assert fitted["selected_azure_rate_percent"] == -3
    assert fitted["post_synthesis_time_stretch_ratio"] == 1.0
    assert fitted["speaker_tempo_locked"] is True
    assert fitted["semantic_fit"]["selected_attempt"] == 1
    assert attempts[-1]["status"] == "selected"
    assert backend.rates == [-3, -3]
    assert provider.fit_calls == 1
    assert provider.review_calls == 1
    assert artifacts.semantic_fit.is_file()


def test_semantic_fit_batches_all_unresolved_blocks_in_one_ai_round(
    tmp_path: Path,
) -> None:
    first = _block()
    second = SpeechBlock(
        block_id="block_0002_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=2000,
        end_ms=4000,
        segment_ids=("unit_0002",),
        source_text="A second source sentence",
        translated_text="Umusho wesibili wemvelo",
        tts_text="Umusho wesibili wemvelo",
        required_facts=("The second sentence remains true",),
    )
    backend = _MeasuredBackend(
        {
            first.translated_text: 2400,
            second.translated_text: 2300,
            "Umusho wokuqala ofushane": 1800,
            "Umusho wesibili ofushane": 1850,
        }
    )
    provider = _SemanticBatchProvider(
        {
            "block_0001": "Umusho wokuqala ofushane",
            "block_0002": "Umusho wesibili ofushane",
        }
    )
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    blocks = (first, second)
    results = renderer._synthesize_semantic_fit_batch(
        blocks,
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        synthesis_profiles={
            0: ("zu-ZA-ThandoNeural", 0, 0, 0),
            1: ("zu-ZA-ThandoNeural", 0, 0, 0),
        },
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
    )

    assert provider.fit_batch_calls == 1
    assert provider.review_batch_calls == 1
    assert results[0][0].translated_text == "Umusho wokuqala ofushane"
    assert results[1][0].translated_text == "Umusho wesibili ofushane"
    assert all(
        result[1]["post_synthesis_time_stretch_ratio"] == 1.0
        for result in results.values()
    )
    assert backend.rates == [0, 0, 0, 0]


def test_semantic_fit_batch_restart_reuses_paid_serial_candidate(
    tmp_path: Path,
) -> None:
    block = _block()
    cached_spoken = "Umusho okhokhelwe osevele ukhona"
    backend = _MeasuredBackend(
        {block.translated_text: 2400, cached_spoken: 1800}
    )
    provider = _SemanticBatchProvider({})
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    artifacts = DirectDubArtifacts(tmp_path / "jobs" / "job-1")
    artifacts.semantic_fit.parent.mkdir(parents=True, exist_ok=True)
    artifacts.semantic_fit.write_text(
        json.dumps(
            {
                "schema_version": SEMANTIC_FIT_SCHEMA_VERSION,
                "job_id": "job-1",
                "cases": {
                    "block_0001": {
                        "status": "exhausted",
                        "speaker_id": "SPEAKER_00",
                        "voice": "zu-ZA-ThandoNeural",
                        "speaker_rate_percent": 0,
                        "attempts": [
                            {
                                "attempt": 1,
                                "request_fingerprint": "old-serial-call",
                                "candidate": {
                                    "schema_version": "claude-turn-repair-v1",
                                    "unit": {
                                        "unit_id": "block_0001",
                                        "faithful_translation": (
                                            block.translated_text
                                        ),
                                        "spoken_text": cached_spoken,
                                        "tts_text": cached_spoken,
                                        "language_features": [],
                                        "human_review_flags": [],
                                        "numbers_preserved": True,
                                        "dates_preserved": True,
                                        "negation_preserved": True,
                                        "omitted_or_compressed_detail": [],
                                    },
                                },
                            }
                        ],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    results = renderer._synthesize_semantic_fit_batch(
        (block,),
        artifacts,
        synthesis_profiles={0: ("zu-ZA-ThandoNeural", 0, 0, 0)},
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
    )

    assert results[0][0].translated_text == cached_spoken
    assert provider.fit_batch_calls == 0
    assert provider.review_batch_calls == 1


def test_new_strategy_gets_fresh_budget_after_old_attempts_are_exhausted(
    tmp_path: Path,
) -> None:
    block = _block()
    old_spoken = "Umusho omdala omude kakhulu"
    new_spoken = "Umusho omusha"
    backend = _MeasuredBackend(
        {
            block.translated_text: 2400,
            old_spoken: 2300,
            new_spoken: 1800,
        }
    )
    provider = _SemanticBatchProvider({"block_0001": new_spoken})
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    artifacts = DirectDubArtifacts(tmp_path / "jobs" / "job-1")
    artifacts.semantic_fit.parent.mkdir(parents=True, exist_ok=True)
    artifacts.semantic_fit.write_text(
        json.dumps(
            {
                "schema_version": SEMANTIC_FIT_SCHEMA_VERSION,
                "job_id": "job-1",
                "strategy_version": "obsolete-strategy",
                "cases": {
                    "block_0001": {
                        "status": "exhausted",
                        "attempts": [
                            {
                                "attempt": 12,
                                "candidate": {
                                    "schema_version": "claude-turn-repair-v1",
                                    "unit": {
                                        "unit_id": "block_0001",
                                        "faithful_translation": block.translated_text,
                                        "spoken_text": old_spoken,
                                        "tts_text": old_spoken,
                                        "language_features": [],
                                        "human_review_flags": [],
                                        "numbers_preserved": True,
                                        "dates_preserved": True,
                                        "negation_preserved": True,
                                        "omitted_or_compressed_detail": [],
                                    },
                                },
                            }
                        ],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    results = renderer._synthesize_semantic_fit_batch(
        (block,),
        artifacts,
        synthesis_profiles={0: ("zu-ZA-ThandoNeural", 0, 0, 0)},
        options=DirectDubOptions(
            timing_mode=TIMING_MODE_SEMANTIC_FIT,
            semantic_fit_max_attempts=1,
        ),
        force=False,
        progress=_DirectDubProgress(None),
    )

    assert results[0][0].translated_text == new_spoken
    assert provider.fit_batch_calls == 1
    checkpoint = json.loads(artifacts.semantic_fit.read_text(encoding="utf-8"))
    latest = checkpoint["cases"]["block_0001"]["attempts"][-1]
    assert latest["attempt"] == 13
    assert latest["strategy_attempt"] == 1


def test_semantic_fit_payload_compacts_repeated_history() -> None:
    block = _block()
    evidence = [
        {
            "attempt": attempt,
            "status": "overflow",
            "spoken_text": f"candidate {attempt}",
            "measured_duration_ms": 3000 - attempt * 50,
            "target_maximum_ms": 2000,
        }
        for attempt in range(1, 13)
    ]

    payload = DirectAzureDubRenderer._semantic_fit_payload(
        block,
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        attempt_number=1,
        target_minimum_ms=1500,
        target_preferred_ms=1750,
        target_maximum_ms=2000,
        duration_evidence=evidence,
        rejected_spoken_texts=[f"candidate {value}" for value in range(12)],
        current_spoken_text="candidate 12",
    )

    assert len(payload["duration_evidence"]) <= 4
    assert len(payload["rejected_spoken_texts"]) == 6
    assert payload["evidence_compaction"] == {
        "input_observation_count": 12,
        "transmitted_observation_count": len(payload["duration_evidence"]),
        "maximum_rejected_texts_transmitted": 6,
    }


def test_semantic_fit_rate_limit_retries_only_pending_review_batch(
    tmp_path: Path,
) -> None:
    block = _block()
    candidate = "Umusho omfushane olingana kahle"
    backend = _MeasuredBackend(
        {block.translated_text: 2400, candidate: 1800}
    )
    provider = _SemanticBatchProvider(
        {"block_0001": candidate},
        review_rate_limits=1,
        retry_after_seconds=0.25,
    )
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )

    results = renderer._synthesize_semantic_fit_batch(
        (block,),
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        synthesis_profiles={0: ("zu-ZA-ThandoNeural", 0, 0, 0)},
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
    )

    assert results[0][0].translated_text == candidate
    assert provider.fit_batch_calls == 1
    assert provider.review_batch_calls == 2
    assert provider.sleep_calls == [0.25]


def test_locked_tempo_pause_budget_uses_semantic_deadline_not_full_block(
    tmp_path: Path,
) -> None:
    text = "Umusho omude kodwa wemvelo"
    backend = _MeasuredBackend({text: 9100})
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
    )
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=11220,
        segment_ids=("unit_0001",),
        source_text="A slow source sentence",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=(
            {
                "source_progress": 0.25,
                "source_gap_ms": 1100,
                "requested_pause_ms": 1000,
            },
            {
                "source_progress": 0.75,
                "source_gap_ms": 1100,
                "requested_pause_ms": 1000,
            },
        ),
        source_speech_start_ms=0,
        source_speech_end_ms=10720,
    )

    fitted = renderer._synthesize_locked_tempo_block(
        block,
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        force=False,
        timing_deadline_ms=10970,
    )

    assert fitted["semantic_timing_deadline_ms"] == 10970
    assert fitted["duration_ms"] == 10870
    assert fitted["duration_ms"] <= 10970
    assert fitted["source_pause_alignment"]["total_added_pause_ms"] == 1770
    assert _selected_azure_measurement_ms(fitted) == 10870


def test_selected_measurement_does_not_choose_shortest_same_rate_attempt() -> None:
    fitted = {
        "selected_azure_rate_percent": 0,
        "azure_attempts": [
            {"rate_percent": 0, "duration_ms": 3575},
            {"rate_percent": 0, "duration_ms": 4512},
            {"rate_percent": 0, "duration_ms": 4476},
        ],
        "duration_ms": 4476,
    }

    assert _selected_azure_measurement_ms(fitted) == 4476


def test_semantic_fit_target_band_uses_full_safe_block_window() -> None:
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=2380,
        segment_ids=("unit_0001",),
        source_text="There is one thing I can tell you for sure.",
        translated_text="Kukhona into eyodwa engingaqiniseka ngayo.",
        tts_text="Kukhona into eyodwa engingaqiniseka ngayo.",
        source_speech_start_ms=0,
        source_speech_end_ms=1880,
    )

    assert DirectAzureDubRenderer._semantic_fit_target_band(block, 250) == (
        1630,
        1880,
        2380,
    )


def test_word_timed_tolerance_is_shared_across_both_mouth_boundaries() -> None:
    block = SpeechBlock(
        block_id="block_0007_variant_semantic_fit_12",
        speaker_id="SPEAKER_00",
        start_ms=72950,
        end_ms=75330,
        segment_ids=("unit_0012",),
        source_text="There is one thing I know.",
        translated_text="kukhon' okunye engikwaz'.",
        tts_text="kukhon' okunye engikwaz'.",
        source_speech_start_ms=72950,
        source_speech_end_ms=74830,
        source_timing_evidence="azure_word_timestamps",
    )

    assert DirectAzureDubRenderer._semantic_fit_target_band(block, 250) == (
        1380,
        1880,
        2380,
    )
    selected, audit = DirectAzureDubRenderer._center_word_timed_delivery(
        block,
        2300,
        250,
    )

    assert (selected.start_ms, selected.end_ms) == (72740, 75040)
    assert audit["start_error_ms"] == -210
    assert audit["endpoint_error_ms"] == 210
    assert audit["within_tolerance"] is True


def test_capacity_aware_islands_fit_exact_failed_block_one(
    tmp_path: Path,
) -> None:
    text = "Bazam' konk' bangiwise. NgoFadile. Uvel' kusasa e-Madlanga Commission. NgoFadiel Adams."
    backend = _MeasuredBackend({text: 8812})
    renderer = DirectAzureDubRenderer(SimpleNamespace(work_dir=tmp_path), backend)
    block = SpeechBlock(
        block_id="block_0001_variant_semantic_fit_09",
        speaker_id="SPEAKER_00",
        start_ms=2390,
        end_ms=13610,
        segment_ids=("unit_0001", "unit_0002"),
        source_text="source",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=(
            {"source_progress": 0.20, "requested_pause_ms": 500, "pause_kind": "phrase_pause"},
            {"source_progress": 0.40, "requested_pause_ms": 620, "pause_kind": "phrase_pause"},
            {"source_progress": 0.60, "requested_pause_ms": 660, "pause_kind": "phrase_pause"},
            {"source_progress": 0.80, "requested_pause_ms": 1180, "pause_kind": "island_boundary"},
        ),
        source_speech_start_ms=2390,
        source_speech_end_ms=13110,
        source_timing_evidence="azure_word_timestamps",
    )

    fitted = renderer._synthesize_locked_tempo_block(
        block,
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        force=False,
        timing_deadline_ms=11220,
        timing_preferred_ms=10720,
    )

    pause = fitted["source_pause_alignment"]
    assert fitted["duration_ms"] == 10720
    assert pause["total_added_pause_ms"] == 1908
    assert next(
        item for item in pause["insertions"]
        if item["pause_kind"] == "island_boundary"
    )["duration_ms"] == 1180
    assert all(
        part <= 2000
        for item in pause["insertions"]
        for part in item["ssml_break_durations_ms"]
    )


def test_word_timed_candidate_cannot_erase_an_island_to_fit(
    tmp_path: Path,
) -> None:
    text = "Inkulumo ende egcwalisa iwindi ngaphandle kwekhefu"
    backend = _MeasuredBackend({text: 10662})
    renderer = DirectAzureDubRenderer(SimpleNamespace(work_dir=tmp_path), backend)
    block = SpeechBlock(
        block_id="block_0001_variant_semantic_fit_01",
        speaker_id="SPEAKER_00",
        start_ms=2390,
        end_ms=13610,
        segment_ids=("unit_0001",),
        source_text="source",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=(
            {
                "source_progress": 0.8,
                "requested_pause_ms": 1180,
                "pause_kind": "island_boundary",
            },
        ),
        source_speech_start_ms=2390,
        source_speech_end_ms=13110,
        source_timing_evidence="azure_word_timestamps",
    )

    with pytest.raises(TimingOverflowError):
        renderer._synthesize_locked_tempo_block(
            block,
            DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
            voice="zu-ZA-ThandoNeural",
            base_rate_percent=0,
            pitch_percent=0,
            volume_percent=0,
            force=False,
            timing_deadline_ms=11220,
            timing_preferred_ms=10720,
        )


def test_capacity_aware_pauses_fill_exact_final_block_underflow(
    tmp_path: Path,
) -> None:
    text = "amazwi aqotho avala inkulumo ende ngendlela yemvelo"
    backend = _MeasuredBackend({text: 11675})
    renderer = DirectAzureDubRenderer(SimpleNamespace(work_dir=tmp_path), backend)
    block = SpeechBlock(
        block_id="block_0021_variant_semantic_fit_02",
        speaker_id="SPEAKER_00",
        start_ms=206510,
        end_ms=227072,
        segment_ids=("unit_0034",),
        source_text="source",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=tuple(
            {
                "source_progress": index / 8,
                "requested_pause_ms": duration_ms,
                "pause_kind": (
                    "island_boundary" if duration_ms >= 800 else "phrase_pause"
                ),
            }
            for index, duration_ms in enumerate(
                (620, 900, 1100, 740, 1180, 980, 1460),
                start=1,
            )
        ),
        source_speech_start_ms=206510,
        source_speech_end_ms=227072,
        source_timing_evidence="azure_word_timestamps",
    )

    fitted = renderer._synthesize_locked_tempo_block(
        block,
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        force=False,
        timing_deadline_ms=20562,
        timing_preferred_ms=20562,
    )

    assert fitted["duration_ms"] == 20562
    assert fitted["source_pause_alignment"]["total_added_pause_ms"] == 8887


def test_locked_tempo_calibrates_measured_pause_overshoot(
    tmp_path: Path,
) -> None:
    text = "Umusho wemvelo onekhefu"
    backend = _PauseOvershootBackend({text: 9000}, pause_overhead_ms=200)
    renderer = DirectAzureDubRenderer(SimpleNamespace(work_dir=tmp_path), backend)
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=10000,
        segment_ids=("unit_0001",),
        source_text="A sentence with a measured pause",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=(
            {
                "source_progress": 0.5,
                "source_gap_ms": 1200,
                "requested_pause_ms": 1100,
            },
        ),
        source_speech_start_ms=0,
        source_speech_end_ms=9900,
    )

    fitted = renderer._synthesize_locked_tempo_block(
        block,
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        force=False,
        timing_deadline_ms=10000,
    )

    assert fitted["duration_ms"] == 9975
    assert fitted["duration_ms"] <= 10000
    assert fitted["source_pause_alignment"][
        "azure_measured_pause_calibration"
    ] is True
    assert fitted["source_pause_alignment"]["total_added_pause_ms"] == 775
    assert backend.rates == [0, 0, 0]


def test_word_timed_pause_overflow_requires_shorter_semantic_delivery(
    tmp_path: Path,
) -> None:
    text = "Umusho onekhefu elivela emazwini omthombo"
    backend = _PauseOvershootBackend({text: 9000}, pause_overhead_ms=200)
    renderer = DirectAzureDubRenderer(SimpleNamespace(work_dir=tmp_path), backend)
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=10000,
        segment_ids=("unit_0001",),
        source_text="A sentence with an authoritative word-timed pause",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=(
            {
                "source_progress": 0.5,
                "source_gap_ms": 1200,
                "requested_pause_ms": 1100,
                "pause_kind": "island_boundary",
            },
        ),
        source_speech_start_ms=0,
        source_speech_end_ms=9900,
        source_timing_evidence="azure_word_timestamps",
    )

    with pytest.raises(TimingOverflowError):
        renderer._synthesize_locked_tempo_block(
            block,
            DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
            voice="zu-ZA-ThandoNeural",
            base_rate_percent=0,
            pitch_percent=0,
            volume_percent=0,
            force=False,
            timing_deadline_ms=10000,
        )

    # Plain speech plus one pause-bearing measurement: the source pause is not
    # shortened by calibration rounds just to make an overlong wording pass.
    assert backend.rates == [0, 0]


def test_semantic_fit_borrows_bounded_same_speaker_transition_room(
    tmp_path: Path,
) -> None:
    first = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=1540,
        segment_ids=("unit_0001",),
        source_text="We need to fast.",
        translated_text="Kudingeka sizile ukudla.",
        tts_text="Kudingeka sizile ukudla.",
        required_facts=("The group needs to fast",),
        source_speech_start_ms=0,
        source_speech_end_ms=1040,
    )
    second = SpeechBlock(
        block_id="block_0002_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=4440,
        end_ms=6000,
        segment_ids=("unit_0002",),
        source_text="A following sentence.",
        translated_text="Umusho olandelayo.",
        tts_text="Umusho olandelayo.",
    )
    candidate = "Kumele sizile."
    backend = _MeasuredBackend(
        {
            first.translated_text: 3500,
            second.translated_text: 1400,
            candidate: 1625,
        }
    )
    provider = _SemanticBatchProvider({"block_0001": candidate})
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    artifacts = DirectDubArtifacts(tmp_path / "jobs" / "job-1")
    artifacts.semantic_fit.parent.mkdir(parents=True, exist_ok=True)
    artifacts.semantic_fit.write_text(
        json.dumps(
            {
                "schema_version": SEMANTIC_FIT_SCHEMA_VERSION,
                "job_id": "job-1",
                "cases": {
                    "block_0001": {
                        "status": "exhausted",
                        "attempt_limit": 12,
                        "attempts": [],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    results = renderer._synthesize_semantic_fit_batch(
        (first, second),
        artifacts,
        synthesis_profiles={
            0: ("zu-ZA-ThandoNeural", 0, 0, 0),
            1: ("zu-ZA-ThandoNeural", 0, 0, 0),
        },
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
    )

    selected, fitted, _audits = results[0]
    assert selected.translated_text == candidate
    assert selected.end_ms == 1625
    assert fitted["semantic_fit"]["same_speaker_transition_borrow_ms"] == 85
    assert (
        fitted["semantic_fit"]["same_speaker_transition_borrow_limit_ms"]
        == 1450
    )
    assert fitted["semantic_fit"]["original_block_end_ms"] == 1540
    assert provider.fit_batch_calls == 1
    assert provider.review_batch_calls == 1


def test_semantic_fit_prefers_approved_natural_text_in_safe_transition(
    tmp_path: Path,
) -> None:
    first = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=2380,
        segment_ids=("unit_0001",),
        source_text="There is one thing I can tell you for sure.",
        translated_text="Kukhona into eyodwa engingaqiniseka ngayo.",
        tts_text="Kukhona into eyodwa engingaqiniseka ngayo.",
        required_facts=("There is one thing the speaker is sure about",),
        source_speech_start_ms=0,
        source_speech_end_ms=1880,
    )
    second = SpeechBlock(
        block_id="block_0002_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=4920,
        end_ms=6500,
        segment_ids=("unit_0002",),
        source_text="The following sentence.",
        translated_text="Umusho olandelayo.",
        tts_text="Umusho olandelayo.",
    )
    backend = _MeasuredBackend(
        {
            first.translated_text: 3400,
            second.translated_text: 1400,
        }
    )
    provider = _SemanticBatchProvider({})
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    artifacts = DirectDubArtifacts(tmp_path / "jobs" / "job-1")
    artifacts.semantic_fit.parent.mkdir(parents=True, exist_ok=True)
    artifacts.semantic_fit.write_text(
        json.dumps(
            {
                "schema_version": SEMANTIC_FIT_SCHEMA_VERSION,
                "job_id": "job-1",
                "cases": {
                    "block_0001": {
                        "status": "exhausted",
                        "attempt_limit": 12,
                        "attempts": [],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    results = renderer._synthesize_semantic_fit_batch(
        (first, second),
        artifacts,
        synthesis_profiles={
            0: ("zu-ZA-ThandoNeural", 0, 0, 0),
            1: ("zu-ZA-ThandoNeural", 0, 0, 0),
        },
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
    )

    selected, fitted, _audits = results[0]
    assert selected.translated_text == first.translated_text
    assert selected.end_ms == 3400
    assert fitted["semantic_fit"]["same_speaker_transition_borrow_ms"] == 1020
    assert fitted["semantic_fit"]["same_speaker_transition_borrow_limit_ms"] == 1270
    assert fitted["semantic_fit"]["search_block_end_ms"] == 3650
    assert fitted["semantic_fit"]["selected_block_end_ms"] == 3400
    assert provider.fit_batch_calls == 0
    assert provider.review_batch_calls == 0
    checkpoint = json.loads(artifacts.semantic_fit.read_text(encoding="utf-8"))
    assert checkpoint["cases"]["block_0001"]["status"] == "selected"
    assert checkpoint["cases"]["block_0001"]["selected_attempt"] == 0


def test_long_source_pauses_fill_and_calibrate_semantic_window(
    tmp_path: Path,
) -> None:
    text = "a b c d e f g h i j k l m n o p"
    backend = _PauseOvershootBackend({text: 13662}, pause_overhead_ms=525)
    renderer = DirectAzureDubRenderer(SimpleNamespace(work_dir=tmp_path), backend)
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=20562,
        segment_ids=("unit_0001",),
        source_text="One slow sentence with seven long pauses.",
        translated_text=text,
        tts_text=text,
        source_pause_anchors=tuple(
            {
                "source_progress": progress,
                "source_gap_ms": 1100,
                "requested_pause_ms": 1000,
            }
            for progress in (0.1, 0.23, 0.36, 0.5, 0.64, 0.77, 0.9)
        ),
        source_speech_start_ms=0,
        source_speech_end_ms=20562,
    )

    fitted = renderer._synthesize_locked_tempo_block(
        block,
        DirectDubArtifacts(tmp_path / "jobs" / "job-1"),
        voice="zu-ZA-ThandoNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        force=False,
        timing_deadline_ms=20562,
    )

    assert fitted["duration_ms"] == 20537
    assert 20312 <= _selected_azure_measurement_ms(fitted) <= 20562
    assert fitted["source_pause_alignment"]["total_added_pause_ms"] == 6350
    assert fitted["source_pause_alignment"]["calibration_reduction_ms"] == 447


def test_direct_backend_uses_ten_second_source_pause_bound(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AZURE_SPEECH_KEY", "test-key")
    settings = SimpleNamespace(
        azure_speech_region="southafricanorth",
        azure_rate_min_percent=-12,
        azure_tts_voices=("zu-ZA-ThandoNeural",),
        azure_tts_default_voice="zu-ZA-ThandoNeural",
        azure_tts_sample_rate=24_000,
        azure_tts_channels=1,
        azure_tts_sample_width=2,
        azure_tts_timeout_seconds=120,
        azure_tts_max_retries=3,
    )

    backend = create_direct_azure_backend(settings, max_rate_percent=15)

    assert backend.ssml_bounds.total_pause_max_ms == 10_000


def test_semantic_fit_accepts_isizulu_prefix_on_multiword_identity() -> None:
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=11220,
        segment_ids=("unit_0001",),
        source_text="Fadiel Adams will appear at the Madlanga Commission.",
        translated_text=(
            "UFadiel Adams uzovela e-Madlanga Commission."
        ),
        tts_text="UFadiel Adams uzovela e-Madlanga Commission.",
        protected_entities=("Madlanga Commission", "Fadiel Adams"),
    )
    candidate = {
        "unit": {
            "unit_id": "block_0001",
            "spoken_text": (
                "Uvela kusasa e-Madlanga Commission. "
                "Ake nginitshele ngoFadiel Adams."
            ),
            "tts_text": (
                "Uvela kusasa e-Madlanga Commission. "
                "Ake nginitshele ngoFadiel Adams."
            ),
            "numbers_preserved": True,
            "dates_preserved": True,
            "negation_preserved": True,
            "omitted_or_compressed_detail": [],
        }
    }

    spoken, tts, omissions = (
        DirectAzureDubRenderer._validate_finalization_candidate(
            block,
            candidate,
        )
    )

    assert "e-Madlanga Commission" in spoken
    assert "ngoFadiel Adams" in tts
    assert omissions == ()


def test_semantic_fit_still_rejects_missing_multiword_identity() -> None:
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=2000,
        segment_ids=("unit_0001",),
        source_text="Madlanga Commission",
        translated_text="iKhomishini kaMadlanga",
        tts_text="iKhomishini kaMadlanga",
        protected_entities=("Madlanga Commission",),
    )
    candidate = {
        "unit": {
            "unit_id": "block_0001",
            "spoken_text": "Uvela kusasa ekhomishini.",
            "tts_text": "Uvela kusasa ekhomishini.",
            "numbers_preserved": True,
            "dates_preserved": True,
            "negation_preserved": True,
            "omitted_or_compressed_detail": [],
        }
    }

    with pytest.raises(ValueError, match="lost protected entities"):
        DirectAzureDubRenderer._validate_finalization_candidate(
            block,
            candidate,
        )


def test_semantic_fit_restart_measures_cached_candidate_without_new_ai_call(
    tmp_path: Path,
) -> None:
    approved = (
        "Bazozama yonke into ukuze bangiwise. "
        "UFadile uvela kusasa e-Madlanga Commission. "
        "Ake nginitshele ngoFadiel Adams."
    )
    cached_spoken = (
        "Bazozama konke ukungiwisa. "
        "UFadile uvela kusasa e-Madlanga Commission. "
        "Ake nginitshele ngoFadiel Adams."
    )
    block = SpeechBlock(
        block_id="block_0001_variant_natural",
        speaker_id="SPEAKER_00",
        start_ms=0,
        end_ms=11220,
        segment_ids=("unit_0001",),
        source_text=(
            "They will try everything to bring me down. Fadiel Adams will "
            "appear at the Madlanga Commission."
        ),
        translated_text=approved,
        tts_text=approved,
        protected_entities=("Madlanga Commission", "Fadiel Adams"),
        required_facts=("They will try to bring the speaker down",),
        source_speech_start_ms=0,
        source_speech_end_ms=10720,
    )
    backend = _MeasuredBackend({approved: 12500, cached_spoken: 10800})
    provider = _SemanticProvider()
    renderer = DirectAzureDubRenderer(
        SimpleNamespace(work_dir=tmp_path),
        backend,
        timing_repair_provider_factory=lambda: provider,
    )
    artifacts = DirectDubArtifacts(tmp_path / "jobs" / "job-1")
    initial_attempt = {
        "attempt": 0,
        "candidate_id": "approved_natural",
        "status": "overflow",
        "spoken_text": approved,
        "measured_duration_ms": 12500,
        "target_minimum_ms": 10470,
        "target_preferred_ms": 10720,
        "target_maximum_ms": 11220,
        "speaker_rate_percent": 0,
        "time_stretch_ratio": 1.0,
        "semantic_review": "approved_translation",
    }
    payload = renderer._semantic_fit_payload(
        block,
        voice="zu-ZA-ThembaNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        attempt_number=1,
        target_minimum_ms=10470,
        target_preferred_ms=10720,
        target_maximum_ms=11220,
        duration_evidence=[initial_attempt],
        rejected_spoken_texts=[approved],
        current_spoken_text=approved,
    )
    fingerprint = hashlib.sha256(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    cached_candidate = {
        "schema_version": "claude-turn-repair-v1",
        "unit": {
            "unit_id": "block_0001",
            "faithful_translation": approved,
            "spoken_text": cached_spoken,
            "tts_text": cached_spoken,
            "language_features": [],
            "human_review_flags": [],
            "numbers_preserved": True,
            "dates_preserved": True,
            "negation_preserved": True,
            "omitted_or_compressed_detail": [],
        },
    }
    artifacts.semantic_fit.parent.mkdir(parents=True, exist_ok=True)
    artifacts.semantic_fit.write_text(
        json.dumps(
            {
                "schema_version": SEMANTIC_FIT_SCHEMA_VERSION,
                "job_id": "job-1",
                "cases": {
                    "block_0001": {
                        "status": "exhausted",
                        "speaker_id": "SPEAKER_00",
                        "voice": "zu-ZA-ThembaNeural",
                        "speaker_rate_percent": 0,
                        "attempts": [
                            {
                                "attempt": 1,
                                "request_fingerprint": fingerprint,
                                "candidate": cached_candidate,
                            }
                        ],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    selected_block, fitted, attempts = renderer._synthesize_semantic_fit(
        block,
        artifacts,
        voice="zu-ZA-ThembaNeural",
        base_rate_percent=0,
        pitch_percent=0,
        volume_percent=0,
        options=DirectDubOptions(timing_mode=TIMING_MODE_SEMANTIC_FIT),
        force=False,
        progress=_DirectDubProgress(None),
        block_number=1,
        block_total=1,
    )

    assert selected_block.translated_text == cached_spoken
    assert fitted["semantic_fit"]["selected_attempt"] == 1
    assert attempts[-1]["ai_called"] is False
    assert provider.fit_calls == 0
    assert provider.review_calls == 1
