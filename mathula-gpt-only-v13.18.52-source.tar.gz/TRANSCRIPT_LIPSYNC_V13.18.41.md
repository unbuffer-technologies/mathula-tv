# Transcript-first lip-sync v13.18.41

This release adds pause-aware speech islands and source-authorized interaction
timing without VAD, visual mouth analysis, PyTorch, or a GPU dependency.

## Architecture

- Approved sentences/blocks remain the semantic translation contract.
- Azure word timestamps become the lip-sync timing authority.
- Word gaps of 150ms, 350ms, and 800ms are recorded as micro-pauses,
  phrase-pauses, and separate speech islands respectively.
- Cross-speaker overlap is detected from literal word-interval intersections.
- Short A-B-A turns are marked as sandwiched interjections so the existing
  per-speaker-track mixer can preserve source-authorized argument overlap.
- Semantic-fit receives speech-island and interaction evidence while retaining
  locked speaker tempo and the approved-translation invariants.

## Backward compatibility

- The existing `mathula-tv dub-azure` CLI and all existing flags are unchanged.
- Existing `SpeechBlock` construction remains valid because every new field has
  a default.
- Transcripts without usable word timestamps fall back to their original block
  boundaries and do not fail the job.
- Legacy close-handoff interjection behavior remains available only for legacy
  transcripts. With Azure word timing, overlap is capped by detected source
  overlap instead of being invented geometrically.
- No approved translation text or translation artifact is modified.

## Output

Each render writes `direct_dub/transcript_lipsync.json`, containing the timing
evidence, speech islands, pauses, interactions, fallback counts, and an explicit
CPU-only compute profile.

## Install and run

Extract the archive without restoring its top-directory metadata, then install:

```bash
tar -xzf mathula-transcript-lipsync-v13.18.41-source.tar.gz \
  -C ~/mathula-tv --no-same-owner --no-same-permissions
cd ~/mathula-tv
source .venv/bin/activate
pip install -e .
```

Your existing command remains valid:

```bash
mathula-tv dub-azure d724a4c947404afeae1d748363b41827 \
  --timing-mode semantic-fit \
  --semantic-fit-max-attempts 12 \
  --semantic-fit-tolerance-ms 250 \
  --live-operation \
  --force
```

## Validation

- 40 targeted regression tests passed.
- Ruff checks passed for the changed Python sources.
- Python byte-compilation passed.
