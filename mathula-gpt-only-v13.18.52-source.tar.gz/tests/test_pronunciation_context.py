from __future__ import annotations

from mathula_tv.direct_azure_dub import DirectAzureDubRenderer
from mathula_tv.pronunciation import (
    PronunciationDictionary,
    PronunciationEntry,
    with_default_organisation_initialisms,
)


def _dictionary() -> PronunciationDictionary:
    return PronunciationDictionary(
        dictionary_version="test-v1",
        language="zu-ZA",
        job_id="job-1",
        job_overrides=(
            PronunciationEntry(
                display_text="noC Mackenzie",
                spoken_text="noC Mackenzie",
                tts_text="no Makenzi",
                language="zu-ZA",
                source="job_override",
                kind="personal_name",
            ),
        ),
    )


def test_reviewed_noc_override_derives_other_zulu_name_contexts() -> None:
    dictionary = with_default_organisation_initialisms(_dictionary())

    assert dictionary.apply("uC Mackenzie").tts_text == "u Makenzi"
    assert dictionary.apply("uMackenzie").tts_text == "u Makenzi"
    assert dictionary.apply("noC Mackenzie").tts_text == "no Makenzi"


def test_semantic_rewrite_reapplies_application_pronunciation() -> None:
    dictionary = with_default_organisation_initialisms(_dictionary())

    tts_text, substitutions = DirectAzureDubRenderer._apply_candidate_pronunciation(
        "U-Adams noC Mackenzie sebeyingozi.",
        "U-Adams noC Mackenzie sebeyingozi.",
        dictionary,
    )

    assert tts_text == "U-Adams no Makenzi sebeyingozi."
    assert substitutions[0]["before"] == "noC Mackenzie"
