# Semantic-fit v13.18.40

This release resolves the final exhausted block in job
`d724a4c947404afeae1d748363b41827` without another language-model call.

## Exact diagnosis

`block_0007` contains the English line:

> There's one thing I can tell you for sure.

The authoritative approved isiZulu translation is:

> Kukhona into eyodwa engingaqiniseka ngayo.

It measures 3,400 ms at the speaker's locked Azure rate. The original block is
2,380 ms, followed by 2,540 ms of silence before the same speaker's next line.

All 12 semantic-fit alternatives were generated while the system advertised an
incorrect 2,130 ms ceiling. This made the candidates progressively remove core
meaning. After the timing ceiling was corrected, attempts 8 and 9 fitted the
window acoustically but the independent reviewer correctly found that they did
not improve on the approved translation.

## Corrected policy

Semantic-fit now follows this order:

1. Measure the authoritative approved translation inside its original block.
2. If it overflows and the next block belongs to the same speaker, retry the
   identical approved text against a safe portion of the intervening silence.
3. Preserve at least half of that silence and at least 100 ms. The absolute
   allowance is capped at 1,500 ms.
4. Commit only the measured amount actually used, never the full allowance.
5. Ask the language model for contractions only if the approved translation
   still cannot fit.

For `block_0007`, the approved translation uses exactly 1,020 ms of the 2,540 ms
same-speaker transition, leaving 1,520 ms intact. Speaker tempo stays at +0%,
no time stretch is used, and no text is changed.

Existing exhausted checkpoint cases selected through this recovery path are
updated to `status: selected`, `selected_attempt: 0`, and
`selected_variant_id: approved_natural`.

Identifiers:

- `mathula-direct-azure-dub-v32-natural-transition-fit-v13.18.40`
- `mathula-semantic-fit-global-batch-v5-natural-transition-fit-v13.18.40`
- `mathula-semantic-fit-validator-v6-natural-transition-fit-v13.18.40`
