# Semantic-fit v13.18.39

This release fixes the three remaining exhausted blocks from job
`d724a4c947404afeae1d748363b41827` after inspecting the complete v13.18.38
checkpoint and Azure manifests.

## Root causes corrected

### Selected Azure measurement

Semantic-fit synthesizes a plain baseline and may then synthesize one or more
pause-bearing versions at the same locked rate. The old measurement helper
selected the shortest attempt at that rate instead of the attempt actually
chosen by the renderer.

For `block_0020`, the renderer correctly selected a calibrated 4,476 ms WAV,
but the validator scored the 3,575 ms no-pause baseline and marked the block as
underfilled. The validator now reads the selected result's raw duration.

### Direct-dub Azure backend

The direct-dub backend factory had the intended 10-second source-pause bound,
but the `dub-azure` CLI path instantiated the generic TTS backend whose bound
was still 5 seconds. The CLI now uses the direct-dub factory.

This lets `block_0021` distribute enough time across its seven verified source
pauses. Azure-measured overshoot is calibrated out of the pauses while the text,
speaker rate, and waveform tempo remain unchanged.

### Same-speaker transition allowance

The maximum same-speaker transition allowance increases from 500 ms to 750 ms.
Only the measured amount required by the selected candidate is committed to the
block boundary. Cross-speaker boundaries remain unavailable, and at least
100 ms before the next same-speaker block remains protected.

For `block_0007`, the faithful cached construction measuring 3,038 ms needs
658 ms beyond the original 2,380 ms block and still leaves 1,882 ms before the
next line.

## Restart behavior

Keep `direct_dub/semantic_fit.json`. On restart:

- `block_0020` should select its already-generated approved natural delivery;
- `block_0021` requires only Azure pause synthesis/calibration;
- `block_0007` replays cached attempts 8 and 9 for semantic review before any
  new candidate generation could occur.

No per-block rate change or post-synthesis time stretch is introduced.

Identifiers:

- `mathula-direct-azure-dub-v31-selected-measurement-v13.18.39`
- `mathula-semantic-fit-global-batch-v4-selected-measurement-v13.18.39`
- `mathula-semantic-fit-validator-v5-selected-measurement-v13.18.39`
