# Semantic fit v13.18.37

This release makes v13.18.36's global semantic-fit batches resumable across
Azure Foundry Claude HTTP 429 rate limits.

- Candidate generation and semantic review remain global batch operations.
- Normal provider calls retain one request attempt and a 180-second timeout.
- Only a confirmed rate-limit response enters the new wait-and-resume loop.
- Azure's `Retry-After`, `retry-after-ms`, or `x-ms-retry-after-ms` value is
  preserved in the provider error and used by the semantic-fit coordinator.
- When Azure supplies no delay, the coordinator uses bounded waits of 15, 30,
  60, then 90 seconds.
- Five rate-limit retries and a six-minute total wait budget are allowed by
  default.
- Timing-fit candidates are checkpointed before batched semantic review, so a
  stopped or restarted process does not regenerate those candidates.
- Existing v13.18.35 and v13.18.36 `semantic_fit.json` checkpoints remain
  reusable.

Optional controls:

```bash
MATHULA_TV_SEMANTIC_FIT_RATE_LIMIT_RETRIES=5
MATHULA_TV_SEMANTIC_FIT_RATE_LIMIT_WAIT_BUDGET_SECONDS=360
MATHULA_TV_SEMANTIC_FIT_TIMEOUT_SECONDS=180
MATHULA_TV_SEMANTIC_FIT_MAX_RETRIES=1
```

Do not delete `working/jobs/<job-id>/direct_dub/semantic_fit.json` when
installing or restarting.
