# Semantic fit v13.18.36

This release replaces the serial per-block Claude loop with global batch
feedback rounds.

- Azure measures every approved block first.
- One Claude request generates one new duration-targeted candidate for every
  unresolved block.
- Azure measures those candidates at the speaker's locked rate.
- Timing-fit winners are independently reviewed in one batched Claude request.
- Only misses or semantic-review rejections continue to the next global round.
- Existing paid candidates in `direct_dub/semantic_fit.json` are consumed before
  any new request, including checkpoints written by v13.18.35.
- Provider calls use medium effort, disabled extended thinking, bounded output,
  a 180-second timeout, and one request attempt by default.
- No per-block tempo changes, post-synthesis time stretch, or cross-speaker
  timing borrowing are enabled.

Optional operation-specific controls:

```bash
MATHULA_TV_SEMANTIC_FIT_TIMEOUT_SECONDS=180
MATHULA_TV_SEMANTIC_FIT_MAX_RETRIES=1
```

Install:

```bash
tar --no-same-owner --no-same-permissions --no-overwrite-dir \
  -xzf mathula-semantic-fit-v13.18.36-source.tar.gz -C ~/mathula-tv
cd ~/mathula-tv
source .venv/bin/activate
pip install -e .
```

Keep the existing `working/jobs/<job-id>/direct_dub/semantic_fit.json` file when
restarting. It is the paid-response checkpoint.
