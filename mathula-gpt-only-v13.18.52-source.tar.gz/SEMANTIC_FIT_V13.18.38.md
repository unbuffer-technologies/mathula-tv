# Semantic-fit v13.18.38

This release fixes the four exhausted blocks captured for job
`d724a4c947404afeae1d748363b41827` without changing speaker tempo or using
post-synthesis time stretch.

## Changes

- The hard semantic-fit ceiling is now the full approved speech-block window.
  Source speech end remains the preferred target, not an artificial hard stop.
- A failed candidate may borrow at most 500 ms from a following silent
  transition when the next block belongs to the same speaker. At least 100 ms
  of transition room is retained, and cross-speaker boundaries are never
  borrowed.
- Source-aligned pauses may use up to 10 seconds in long blocks. The previous
  5-second total cap forced faithful long translations to underfill and caused
  the language model to add unnecessary filler.
- Semantic-fit pause allocation uses the available window while retaining the
  relative source-gap pattern. Azure's measured pause-bearing result is then
  calibrated proportionally, with a 25 ms guard, until it is inside the hard
  boundary.
- Existing candidates and audio remain restartable. The global checkpoint is
  replayed before any new candidate-generation round.

## Expected recovery for the supplied job

- `block_0007`: the 2,325 ms first candidate is valid inside the 2,380 ms
  source block (and the bounded same-speaker transition remains available).
- `block_0016`: the faithful 1,625 ms contraction can use 85 ms beyond the
  original 1,540 ms block while leaving more than two seconds before the next
  same-speaker block.
- `block_0020`: the approved natural 4,262 ms source-pause delivery fits the
  actual 4,500 ms block; the former 4,250 ms ceiling was incorrect.
- `block_0021`: the approved translation can fill its 20,562 ms window through
  its seven source-aligned pauses. Azure-measured overshoot is removed from the
  pauses, not from the words or speaker tempo.

The strategy and validator identifiers are:

- `mathula-semantic-fit-global-batch-v3-boundary-aware-v13.18.38`
- `mathula-semantic-fit-validator-v4-boundary-aware-v13.18.38`
- `mathula-direct-azure-dub-v30-boundary-aware-semantic-fit-v13.18.38`
